---
name: Documentation
about: Found a typo or something that isn't crystal clear in our docs?
title: 'docs: '
labels: documentation
assignees: DirtyF

---

<!-- Thanks for taking the time to open an issue and help us make Jekyll better! -->

## Motivation

<!-- Why should we update our docs? -->



## Suggestion

<!-- What should we do instead? -->



<!-- Thanks for taking the time to open an issue and help us make Jekyll better! -->
